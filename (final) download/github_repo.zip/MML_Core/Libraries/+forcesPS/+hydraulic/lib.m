function lib( libInfo )
% Customize library
% Copyright 2005-2022 The MathWorks, Inc

libInfo.Name = 'Hydraulic';
end
