% make_plots.m
%
% Make Matlab figures *after* a Simulink simulation.
%
% Run by clicking on the Simulink block, or at the command line.
%
% Marc Compere, comperem@erau.edu
% created : 01 May 2022
% modified: 01 May 2022

figure(10),clf
plot(X(:,2),Y(:,2),'b.-')
xlabel('X-axis (m)')
ylabel('Y-axis (m)')
set(gca,'YDir','reverse') % show SAE coordinates with +Y down 
grid on
axis equal
str=sprintf('Distance Traveled=%0.2f(m)', max(dist_m(:,2)) );
text(mean(X(:,2)),mean(Y(:,2)),str)


figure(11),clf
plot(acc_lat(:,1),acc_lat(:,2),'g.-')
xlabel('time (s)')
ylabel('Lateral Acceleration (g)')
grid on


figure(12),clf
plot(rho(:,1),rho(:,2),'b.-')
xlabel('time (s)')
ylabel('Curvature (1/m)')
grid on


  